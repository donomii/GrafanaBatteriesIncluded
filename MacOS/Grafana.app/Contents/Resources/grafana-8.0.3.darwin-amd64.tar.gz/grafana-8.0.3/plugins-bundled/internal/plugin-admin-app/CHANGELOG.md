# Change Log

Changes are included in the grafana core changelog